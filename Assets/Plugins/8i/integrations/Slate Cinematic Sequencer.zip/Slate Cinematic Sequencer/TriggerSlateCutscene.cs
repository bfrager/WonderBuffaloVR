﻿using UnityEngine;
using Slate;

public class TriggerSlateCutscene : MonoBehaviour
{
    public Cutscene targetCutscene;

    void Start()
    {
        if (targetCutscene)
            targetCutscene.Play();
    }
}
