﻿using UnityEngine;
using HVR;
using Slate;

namespace Slate.ActionClips
{
    [Category("8i")]
    [Name("Play HvrActor")]
    [Description("Triggers playback of the HVR Actor")]
    public class HVRActorAction : ActorActionClip
    {
        [SerializeField]
        [HideInInspector]
        private float _length = 1f;

        public override float length
        {
            get { return _length; }
            set { _length = value; }
        }

        public override bool isValid
        {
            get { return actor != null; }
        }

        public override string info
        {
            get { return isValid ? actor.ToString() : base.info; }
        }

        private HvrActor hvrActor
        {
            get { return actor.GetComponent<HvrActor>(); }
        }

        protected override void OnEnter()
        {
            if (hvrActor.hvrAsset != null)
            {
                hvrActor.hvrAsset.Seek(0);
            }
        }

        protected override void OnUpdate(float targetTime, float previousTime)
        {
            if (hvrActor == null || hvrActor.hvrAsset == null)
                return;

            // Make sure the target time is within the duration of the clip
            if (targetTime < 0 && targetTime > length)
                return;

            if (targetTime >= 0 && targetTime < hvrActor.hvrAsset.GetDuration())
            {
                Cutscene cutscene = (Cutscene)this.parent.root;

                if (cutscene.isActive == true &&
                    cutscene.isPaused == false &&
                    targetTime != previousTime)
                {
                    if (!hvrActor.hvrAsset.IsPlaying())
                        hvrActor.hvrAsset.Play();

                    float delta = targetTime - hvrActor.hvrAsset.GetCurrentTime();

                    if (Mathf.Abs(delta) > 0.2f)
                        hvrActor.hvrAsset.Seek(targetTime);
                }
                else
                {
                    if (hvrActor.hvrAsset.GetCurrentTime() != targetTime)
                    {
                        hvrActor.hvrAsset.Seek(targetTime);
                        hvrActor.hvrAsset.Pause();
                    }
                }
            }
            else
            {
                // If the target time is outside the range of this hvrAsset, pause all playback
                if (hvrActor.hvrAsset.IsPlaying())
                    hvrActor.hvrAsset.Pause();
            }
        }

        protected override void OnExit()
        {
            if (hvrActor.hvrAsset != null)
            {
                hvrActor.hvrAsset.Seek(0);
                hvrActor.hvrAsset.Pause();
            }
        }

        protected override void OnReverse()
        {
            if (hvrActor.hvrAsset != null)
            {
                hvrActor.hvrAsset.Seek(0);
                hvrActor.hvrAsset.Pause();
            }
        }
    }
}